
public class ChannelA extends Channel{

}
