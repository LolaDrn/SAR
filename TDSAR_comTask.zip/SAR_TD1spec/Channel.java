import java.io.IOException;

public abstract class Channel {
	private boolean isDisconnected=true;
	private CircularBuffer buf=new CircularBuffer(100);
	private Channel match;
	

	public void setMatch(Channel match) {
		this.match = match;
	}

	public Channel() {
		this.isDisconnected = false;
	}
	
	public int read(byte[] bytes, int offset, int length) throws IOException{
		//si deconnexion d'un des cote on ferme tout
		if (this.match.disconnected() || this.isDisconnected) { 
			this.match.disconnect();
			this.disconnect();
			throw new IOException("Channels have been disconnected");
		}
        int i = 0;

        try {
        	//bloquant tant qu'il n'y a rien a lire
    		while (this.buf.empty()) {
    			synchronized(this) {
					this.wait();
				}
    		}
    		if (length == 0) {
                return 0;
            }

    		while (i < bytes.length-1 && i < length-1) {
    			//si deconnexion d'un des cote on ferme tout
    			if (this.match.disconnected() || this.isDisconnected) { 
    				this.match.disconnect();
    				this.disconnect();
    				throw new IOException("Channels have been disconnected");
    			}
            	bytes[offset + i] = buf.pull();
            	i++;
            }
            	
        } 
        catch (Exception e) {
        	e.printStackTrace();
			System.out.println("Any bytes have been read");
			return 0;        }
        return i;

  	}
	
    public int write(byte[] bytes, int offset, int length) throws IOException { 
    	//si deconnexion d'un des cote on ferme tout
    			if (this.match.disconnected() || this.isDisconnected) { 
    				this.match.disconnect();
    				this.disconnect();
    				throw new IOException("Channels have been disconnected");
    			}
    	        int i = 0;
    	try {

    		while (i < bytes.length-1 && i < length-1) {
    			//si deconnexion d'un des cote on ferme tout
    			if (this.match.disconnected() || this.isDisconnected) { 
    				this.match.disconnect();
    				this.disconnect();
    				throw new IOException("Channels have been disconnected");
    			}
    			//on ecrit dans le buffer du channel auquel on est connecte
    			this.match.buf.push(bytes[offset +i]);
           		i++;
            	}
    	}
    	catch (Exception e) {
        	e.printStackTrace();
			System.out.println("Any bytes have been read");
			return 0;        }
        return i; 
    	}
    
    public void disconnect() {
    	isDisconnected=true;
    }
    
    public boolean disconnected() { 
    	if (isDisconnected=true) {
    		return true; 
    	}
    	return false;
    }
}
