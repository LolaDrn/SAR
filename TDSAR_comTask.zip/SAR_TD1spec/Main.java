import java.util.HashMap;

public class Main {
	public static HashMap<String, Broker> brokerManager = new HashMap<String, Broker>();

	public static void main (String args[]) {
				
		TaskA A=new TaskA("A");
		TaskA B=new TaskA("B");
		
		A.start();
		B.start();
		
		try {
			A.join();
			B.join();
		}catch(Exception e) {
			e.printStackTrace();
		}
		}
	
}
