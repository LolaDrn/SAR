
public abstract class Task extends Thread{
	protected BrokerA broker;
	
	public Task(String brokerName){
		this.broker=new BrokerA(brokerName);
	}
	
}

