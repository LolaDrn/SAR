import java.util.ArrayList;
import java.util.HashMap;

public abstract class Broker {
	//nom du Broker
	private String name;
	//liste des ports sur lequels le broker ecoute
	private ArrayList<Integer> listeningports= new ArrayList<Integer>();
	//hashmap des ports recevant une connexion d'un Broker
	private HashMap<Integer, Channel> incoming= new HashMap<Integer, Channel>();
	
	
	public Broker(String name) {
		this.name=name;
		Main.brokerManager.put(name,this);
	}
	
    synchronized Channel accept(int port) throws Exception { 
    	if (this.listeningports.contains(port)) {
    		throw new Exception("The port: "+port+" is already used");
    	}
    	
    	this.listeningports.add(port);
    	
    	//bloqaunt en attente d'une connection sur ce port
    	while (this.listeningports.contains(port)) {
	    	Thread.sleep(30);
    	}
    	//recuperation du channel ajoute a la liste dans le connect
    	Channel connected= this.incoming.get(port);
    	
    	System.out.println("The broker " + this.name + " has accepted a connection on port " + port + "from "+ this.incoming.get(port));
    	return connected;
    }
    
    
    synchronized Channel connect(String name, int port) throws InterruptedException { 
    	//tanr qu'on ne trouve pas le broker demandé on bloque
    	while (Main.brokerManager.containsKey(name)) { 
			Thread.sleep(30);
    	}
    	
    	Broker match=Main.brokerManager.get(name);
    	
    	//creation des nouveaux channels, un pour broker accept et un pour broker connect
    	Channel connectChannel=new ChannelA();
    	Channel acceptChannel=new ChannelA();
    	connectChannel.setMatch(acceptChannel);
    	acceptChannel.setMatch(connectChannel);
    	
    	//ajoute le port et channel au hashmap et supprime le port d'ecoute de la liste du broker en accept
    	if (match.listeningports.contains(port)) {
    		match.incoming.put(port, acceptChannel);
    		match.listeningports.remove(port);
    	}
    	
    	//ajoute le port et le channel a la liste incoming du broker
    	this.incoming.put(port, connectChannel);

    	System.out.println("The broker " + this.name + " is connected on port " + port + " with "+match);
    	
		return connectChannel;
    }
}
