
public class BrokerA extends Broker{

	public BrokerA(String name) {
		super(name);
		// TODO Auto-generated constructor stub
	}


}
